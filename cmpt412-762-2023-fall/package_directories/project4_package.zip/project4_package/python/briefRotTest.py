import cv2
import numpy as np
import matplotlib.pyplot as plt

## Read the image and convert to grayscale, if necessary


## Compute the features and descriptors


## Initialize histogram
histogram = np.zeros(37)

for i in range(37): # 0 to 360 degrees in steps of 10. Visualize 0 degree both first and last
    pass
    ## Rotate image
    

    ## Compute features and descriptors
    

    ## Match features
    
    
    ## Update histogram


# Display histogram
plt.bar(range(37), histogram)
plt.savefig(f'../results/rotation_hist.png', dpi=300)
plt.close()


## visualize the feature matching result at three different rotation angles. 
## Include results in your report

