import cv2
import numpy as np

def compositeH(H2to1, template, img):
    ## COMPOSITE Create a composite image after warping the template image on top
    ## of the image using the homography
    ## 
    ##  Note that the homography we compute is from the image to the template;
    ##  x_template = H2to1*x_photo
    ##  For warping the template to the image, we need to invert it.
    H1to2 = np.linalg.inv(H2to1)

    ## Create a mask of the same size as the template

    ## Warp the mask using the computed homography

    ## Warp the template using the computed homography (hint: cv2.warpPerspective)

    ## Use the mask to combine the warped template and the image
    composite_img = None 

    return composite_img

