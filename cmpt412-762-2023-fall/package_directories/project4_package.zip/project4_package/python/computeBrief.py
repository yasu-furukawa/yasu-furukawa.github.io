import numpy as np
import scipy.io

def computeBrief(img, locs_in):
    data = scipy.io.loadmat('../data/brief-indices.mat')
    compareX = data['compareX'].astype(int)
    compareY = data['compareY'].astype(int)
    pattern_size = data['pattern_size'][0,0].astype(int)
    
    img_width = img.shape[1]
    img_height = img.shape[0]

    half = pattern_size // 2
    halfup = -(-pattern_size // 2)

    locs = []
    for loc in locs_in:
        x, y = loc.pt
        
        if x < pattern_size or x >= (img_width-pattern_size) or y < pattern_size or y >= (img_height-pattern_size):
            continue
        
        locs.append(loc)
    
    n = 256
    desc = np.zeros((len(locs), n), dtype=np.float32)

    for i, loc in enumerate(locs):
        x, y = loc.pt
        x = int(x)
        y = int(y)
        
        patch = img[y-half:y+halfup, x-half:x+halfup]
        patch = patch.reshape(-1, order='F')
        
        val_x = patch[compareX[:,0]-1]
        val_y = patch[compareY[:,0]-1]
        bit_value = (val_x < val_y).astype(int) # 256
        desc[i] = bit_value
            
    return locs, desc