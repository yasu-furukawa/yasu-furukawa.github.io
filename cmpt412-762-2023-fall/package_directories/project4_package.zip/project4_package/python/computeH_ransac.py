import numpy as np
import random
from computeH_norm import computeH_norm

def computeH_ransac(locs1, locs2):
    ## COMPUTEH_RANSAC A method to compute the best fitting homography 
    ## given a list of matching points.
    
    bestH2to1 = None
    inliers = None   # the indices of inliers
    best_ids = None  # the indices of the best 4 point-pairs

    return bestH2to1, inliers, best_ids
