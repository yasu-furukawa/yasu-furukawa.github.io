from computeH import computeH

def computeH_norm(x1, x2):
    ## Compute centroids of the points
    centroid1 = None
    centroid2 = None

    ## Shift the origin of the points to the centroid

    ## Normalize the points so that the average distance from the origin is equal to sqrt(2).

    ## Similarity transform 1
    T1 = None

    ## Similarity transform 2
    T2 = None

    ## Compute Homography

    ## Denormalization
    H2to1 = None

    return H2to1
