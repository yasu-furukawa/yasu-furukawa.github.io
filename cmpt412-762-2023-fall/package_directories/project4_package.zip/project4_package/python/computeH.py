import numpy as np

def computeH(x1, x2):
    ## COMPUTEH Computes the homography between two sets of points
    H2to1 = None

    return H2to1


