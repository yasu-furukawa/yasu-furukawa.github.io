import cv2

def loadVid(path):
    cap = cv2.VideoCapture(path)
    
    nFrames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    vidWidth = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    vidHeight = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    # Preallocate movie structure
    mov = [None] * nFrames
    
    # Read one frame at a time
    for k in range(nFrames):
        print(f'{k+1}/{nFrames}')
        ret, frame = cap.read()
        if ret:
            mov[k] = {'cdata': frame, 'colormap': None}
    
    cap.release()
    
    return mov

if __name__ == '__main__':
    path = '../data/ar_source.mov'
    mov = loadVid(path)
    print(mov)
