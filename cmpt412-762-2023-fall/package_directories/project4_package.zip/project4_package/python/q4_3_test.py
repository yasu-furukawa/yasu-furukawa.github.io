import cv2
import matplotlib.pyplot as plt
import numpy as np
from computeBrief import computeBrief
from matchPics import match_features
from computeH import computeH

im1 = cv2.imread('../data/cv_desk.png')
im2 = cv2.imread('../data/cv_cover.jpg')

## Detect features in both two images
## Either use FAST+BRIEF or SURF, whichever works better
## Opencv-contrib-python package is required for SURF, see handout 4.2 for more details
des_1, locs_1 = None, None
des_2, locs_2 = None, None

## Match features between the two images
matches = match_features(des_1, des_2, max_ratio=0.8, match_threshold=10.0)
# hint: adjust max_ratio to filter out bad matches

## Extract matched point-pairs
pt1 = None
pt2 = None

## compute the homography between the two images
H2to1 = computeH(pt1, pt2)
print(H2to1)

## generate a list of random points in image 2
test_pt2 = np.random.randint(0, min(im2.shape[:2]), size=(15, 2))
test_pt2_one = np.concatenate((test_pt2, np.ones((test_pt2.shape[0], 1))), axis=1)

test_pt1_homo = np.matmul(test_pt2_one, H2to1.T)
test_pt1 = test_pt1_homo[:,:2] / test_pt1_homo[:,2:]

## draw the figure
# use cv2.drawMatches()
test_kp1 = [cv2.KeyPoint(x,y,10) for x,y in test_pt1]
test_kp2 = [cv2.KeyPoint(x,y,10) for x,y in test_pt2]
# create match objects
matches = [cv2.DMatch(i, i, 0) for i in range(len(test_pt1))]
img = cv2.drawMatches(im1, test_kp1, im2, test_kp2, matches, None, flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

plt.imshow(img[...,::-1])
plt.savefig('../results/q4_3.png', dpi=300)
