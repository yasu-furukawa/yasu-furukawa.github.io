import cv2
import matplotlib.pyplot as plt
import numpy as np

cv_desk_img = cv2.imread('../data/cv_desk.png')
cv_cover_img = cv2.imread('../data/cv_cover.jpg')
hp_cover_img = cv2.imread('../data/hp_cover.jpg')

## Extract features and match

## Compute homography using RANSAC

## Scale harry potter image to template size
# Why is this is important?

## Display warped image.
# hint: use cv2.warpPerspective
warped_hp_img = None

## Display composite image
composite_img = None



