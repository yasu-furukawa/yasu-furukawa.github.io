import cv2
import numpy as np
import matplotlib.pyplot as plt
from computeBrief import computeBrief

def match_features(des_1, des_2, max_ratio=0.9, match_threshold=10.0):
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(des_1, des_2, k=2)

    # Apply ratio test
    good_matches = []
    for m, n in matches:
        if m.distance < max_ratio * n.distance:
            good_matches.append(m)

    # Filter matches based on the match threshold
    good_matches = [m for m in good_matches if m.distance < match_threshold]
    
    # Sort matches based on their distances
    good_matches = sorted(good_matches, key=lambda x: x.distance)
    
    
    return good_matches


def match_pics(I1, I2, display=False):
    """
    Extract features, obtain their descriptors, and match them!
    """

    ## Convert images to grayscale if necessary


    ## Detect features in both images (hint use cv2.FastFeatureDetector_create())


    ## Compute descriptors for the detected features
    ## Use provided function computeBrief() to compute the descriptors


    ## Match the features using the descriptors
    ## Use provide function match_features() to compute the matches between the descriptors
    ## You may need to tune the max_ratio and match_threshold parameters to have better matching points
    
    
    ## Extract locations of matched features
    locs1 = None
    locs2 = None

    if display:
        ## Display the matched point-pairs. Hint: use cv2.drawMatches(). 
        pass

    return locs1, locs2

if __name__ == '__main__':
    I1 = cv2.imread('../data/cv_cover.jpg')
    I2 = cv2.imread('../data/cv_desk.png')
    match_pics(I1, I2, display=True)
